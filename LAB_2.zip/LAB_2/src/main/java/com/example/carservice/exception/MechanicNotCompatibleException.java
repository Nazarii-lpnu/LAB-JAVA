package com.example.carservice.exception;

public class MechanicNotCompatibleException extends DomainException {
    public MechanicNotCompatibleException(String message) {
        super(message);
    }
}
