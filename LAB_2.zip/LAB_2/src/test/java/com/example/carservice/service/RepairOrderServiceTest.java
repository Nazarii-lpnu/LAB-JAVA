package com.example.carservice.service;

import com.example.carservice.domain.Car;
import com.example.carservice.domain.Customer;
import com.example.carservice.domain.RepairOrder;
import com.example.carservice.domain.ServiceWork;
import com.example.carservice.domain.MechanicSpecialization;
import com.example.carservice.pricing.PricingPolicy;
import com.example.carservice.repository.RepairOrderRepository;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class RepairOrderServiceTest {
    @Test
    void calculatesCommercialPriceThroughInjectedPolicyAndPersistsOrder() {
        RepairOrderRepository repository = mock(RepairOrderRepository.class);
        PricingPolicy policy = mock(PricingPolicy.class);
        Customer customer = new Customer(UUID.randomUUID(), "Customer");
        RepairOrder order = new RepairOrder(UUID.randomUUID(),
                new Car("VIN-SERVICE", "Brand", "Model", 2020, customer));
        order.addWork(new ServiceWork(UUID.randomUUID(), "Work", MechanicSpecialization.ENGINE,
                new BigDecimal("10.00"), new BigDecimal("20.00"), Duration.ofHours(1)));
        when(repository.findById(order.getId())).thenReturn(Optional.of(order));
        when(policy.calculatePrice(order)).thenReturn(new BigDecimal("42.00"));

        RepairOrderService service = new RepairOrderService(repository, policy);

        assertEquals(new BigDecimal("42.00"), service.calculateCommercialPrice(order.getId()));
        verify(policy).calculatePrice(order);
        verify(repository).update(order);
    }
}
