package com.example.carservice.regression;

import com.example.carservice.TestFixtures;
import com.example.carservice.domain.Car;
import com.example.carservice.domain.Customer;
import com.example.carservice.domain.Gift;
import com.example.carservice.domain.GiftType;
import com.example.carservice.domain.Mechanic;
import com.example.carservice.domain.MechanicSpecialization;
import com.example.carservice.domain.RepairOrder;
import com.example.carservice.domain.ServiceWork;
import com.example.carservice.domain.TimeSlot;
import com.example.carservice.exception.EntityAlreadyExistsException;
import com.example.carservice.exception.EntityNotFoundException;
import com.example.carservice.exception.InvalidArgumentException;
import com.example.carservice.exception.MechanicAlreadyAssignedException;
import com.example.carservice.exception.ScheduleConflictException;
import com.example.carservice.repository.inmemory.InMemoryRepairOrderRepository;
import com.example.carservice.service.CarService;
import com.example.carservice.service.RepairOrderService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class Laboratory1RegressionTest {
    @Test
    void registersCustomerCarAndMechanicAndCreatesOrder() {
        RepairOrderService orderService = new RepairOrderService(new InMemoryRepairOrderRepository());
        CarService service = new CarService(orderService);
        Customer customer = service.registerCustomer("Customer");
        Car car = service.registerCar("VIN-REG", "Brand", "Model", 2020, customer.getId());
        Mechanic mechanic = service.registerMechanic("Mechanic", MechanicSpecialization.GENERAL);

        RepairOrder order = service.createOrder(car.getVin());

        assertEquals(car, order.getCar());
        assertEquals(mechanic, service.findMechanicById(mechanic.getId()));
    }

    @Test
    void rejectsDuplicateCarVin() {
        CarService service = configuredCarService();
        Customer customer = service.registerCustomer("Customer");
        service.registerCar("VIN-DUP", "Brand", "Model", 2020, customer.getId());

        assertThrows(EntityAlreadyExistsException.class,
                () -> service.registerCar("VIN-DUP", "Other", "Model", 2021, customer.getId()));
    }

    @Test
    void searchesCarByTrimmedVinAndRejectsUnknownVin() {
        CarService service = configuredCarService();
        Customer customer = service.registerCustomer("Customer");
        Car car = service.registerCar("VIN-SEARCH", "Brand", "Model", 2020, customer.getId());

        assertEquals(car, service.findCarByVin(" VIN-SEARCH "));
        assertThrows(EntityNotFoundException.class, () -> service.findCarByVin("UNKNOWN"));
    }

    @Test
    void rejectsOrderCreationForUnknownCar() {
        CarService service = configuredCarService();

        assertThrows(EntityNotFoundException.class, () -> service.createOrder("UNKNOWN"));
    }

    @Test
    void timeSlotCalculatesEndAndDetectsOverlap() {
        TimeSlot first = new TimeSlot(LocalDateTime.of(2026, 1, 1, 9, 0), Duration.ofHours(2));
        TimeSlot overlapping = new TimeSlot(LocalDateTime.of(2026, 1, 1, 10, 0), Duration.ofHours(1));
        TimeSlot adjacent = new TimeSlot(LocalDateTime.of(2026, 1, 1, 11, 0), Duration.ofHours(1));

        assertEquals(LocalDateTime.of(2026, 1, 1, 11, 0), first.getEnd());
        assertTrue(first.overlaps(overlapping));
        assertFalse(first.overlaps(adjacent));
    }

    @ParameterizedTest(name = "invalid slot duration {0}")
    @MethodSource("invalidSlotDurations")
    void rejectsNonPositiveTimeSlotDurations(Duration duration) {
        assertThrows(InvalidArgumentException.class,
                () -> new TimeSlot(LocalDateTime.of(2026, 1, 1, 9, 0), duration));
    }

    private static Stream<Arguments> invalidSlotDurations() {
        return Stream.of(
                Arguments.of(Duration.ZERO),
                Arguments.of(Duration.ofMinutes(-1))
        );
    }

    @Test
    void schedulingRejectsOverlappingActiveMechanicOrders() {
        InMemoryRepairOrderRepository repository = new InMemoryRepairOrderRepository();
        RepairOrderService service = new RepairOrderService(repository);
        RepairOrder first = TestFixtures.order();
        RepairOrder second = new RepairOrder(UUID.randomUUID(), TestFixtures.car(TestFixtures.customer()));
        Mechanic mechanic = new Mechanic(UUID.randomUUID(), "Mechanic", MechanicSpecialization.GENERAL);
        first.addWork(TestFixtures.work());
        second.addWork(TestFixtures.work());
        service.create(first);
        service.create(second);
        service.assignMechanic(first.getId(), mechanic);
        service.plan(first.getId(), LocalDateTime.of(2026, 1, 1, 9, 0), Duration.ofHours(2));

        service.plan(second.getId(), LocalDateTime.of(2026, 1, 1, 10, 0), Duration.ofHours(2));

        assertThrows(ScheduleConflictException.class,
                () -> service.assignMechanic(second.getId(), mechanic));
    }

    @Test
    void schedulingRejectsUnplannedActiveMechanicOrder() {
        InMemoryRepairOrderRepository repository = new InMemoryRepairOrderRepository();
        RepairOrderService service = new RepairOrderService(repository);
        RepairOrder first = TestFixtures.order();
        RepairOrder second = new RepairOrder(UUID.randomUUID(), TestFixtures.car(TestFixtures.customer()));
        Mechanic mechanic = new Mechanic(UUID.randomUUID(), "Mechanic", MechanicSpecialization.GENERAL);
        first.addWork(TestFixtures.work());
        second.addWork(TestFixtures.work());
        service.create(first);
        service.create(second);
        service.assignMechanic(first.getId(), mechanic);

        assertThrows(MechanicAlreadyAssignedException.class,
                () -> service.assignMechanic(second.getId(), mechanic));
    }

    @Test
    void completedMechanicOrderDoesNotBlockLaterAssignment() {
        InMemoryRepairOrderRepository repository = new InMemoryRepairOrderRepository();
        RepairOrderService service = new RepairOrderService(repository);
        Mechanic mechanic = new Mechanic(UUID.randomUUID(), "Mechanic", MechanicSpecialization.GENERAL);
        RepairOrder completed = TestFixtures.order();
        ServiceWork completedWork = TestFixtures.work();
        completed.addWork(completedWork);
        service.create(completed);
        service.assignMechanic(completed.getId(), mechanic);
        service.diagnose(completed.getId());
        service.approve(completed.getId());
        service.start(completed.getId());
        service.completeWork(completed.getId(), completedWork.getId());
        service.complete(completed.getId());
        RepairOrder later = new RepairOrder(UUID.randomUUID(), TestFixtures.car(TestFixtures.customer()));
        later.addWork(TestFixtures.work());
        service.create(later);

        service.assignMechanic(later.getId(), mechanic);

        assertEquals(mechanic, later.getMechanic());
    }

    @Test
    void repositorySearchByCarAndMechanicPreservesOriginalFeatures() {
        InMemoryRepairOrderRepository repository = new InMemoryRepairOrderRepository();
        RepairOrderService service = new RepairOrderService(repository);
        RepairOrder order = TestFixtures.order();
        Mechanic mechanic = new Mechanic(UUID.randomUUID(), "Mechanic", MechanicSpecialization.GENERAL);
        service.create(order);
        service.assignMechanic(order.getId(), mechanic);

        assertEquals(List.of(order), service.findByCarVin(order.getCar().getVin()));
        assertEquals(List.of(order), service.findByMechanic(mechanic));
    }

    @Test
    void removingWorkPreservesOrderAndPricingBehavior() {
        RepairOrder order = TestFixtures.order();
        ServiceWork retained = TestFixtures.work(MechanicSpecialization.ENGINE, "10.00", "20.00", 1);
        ServiceWork removed = TestFixtures.work(MechanicSpecialization.BRAKES, "30.00", "40.00", 1);
        order.addWork(retained);
        order.addWork(removed);

        order.removeWork(removed.getId());

        assertEquals(List.of(retained), order.getWorks());
        assertEquals(new BigDecimal("30.00"), order.calculateBaseCost());
    }

    @ParameterizedTest(name = "gift amount {0} -> {1}")
    @MethodSource("giftCases")
    void giftThresholdsRemainCompatibleWithLaboratory1(String amount, GiftType expectedType) {
        var gift = Gift.forOrderAmount(new BigDecimal(amount));

        assertTrue(gift.isPresent());
        assertEquals(expectedType, gift.orElseThrow().getType());
    }

    private static Stream<Arguments> giftCases() {
        return Stream.of(
                Arguments.of("100.00", GiftType.AIR_FRESHENER),
                Arguments.of("250.00", GiftType.CAR_CARE_KIT),
                Arguments.of("500.00", GiftType.FREE_DIAGNOSTICS)
        );
    }

    @Test
    void noGiftIsReturnedBelowFirstThreshold() {
        assertTrue(Gift.forOrderAmount(new BigDecimal("99.99")).isEmpty());
    }

    @Test
    void generalMechanicCanPerformEveryWorkType() {
        Mechanic mechanic = new Mechanic(UUID.randomUUID(), "General", MechanicSpecialization.GENERAL);

        assertTrue(mechanic.canPerform(TestFixtures.work(MechanicSpecialization.ENGINE, "1.00", "1.00", 1)));
        assertTrue(mechanic.canPerform(TestFixtures.work(MechanicSpecialization.BRAKES, "1.00", "1.00", 1)));
    }

    private static CarService configuredCarService() {
        return new CarService(new RepairOrderService(new InMemoryRepairOrderRepository()));
    }
}
