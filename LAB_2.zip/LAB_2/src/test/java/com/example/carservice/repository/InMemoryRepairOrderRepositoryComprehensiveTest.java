package com.example.carservice.repository;

import com.example.carservice.TestFixtures;
import com.example.carservice.domain.Mechanic;
import com.example.carservice.domain.MechanicSpecialization;
import com.example.carservice.domain.RepairOrder;
import com.example.carservice.exception.EntityAlreadyExistsException;
import com.example.carservice.exception.EntityNotFoundException;
import com.example.carservice.exception.InvalidArgumentException;
import com.example.carservice.repository.inmemory.InMemoryRepairOrderRepository;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class InMemoryRepairOrderRepositoryComprehensiveTest {
    @Test
    void saveReturnsAndStoresSameOrder() {
        InMemoryRepairOrderRepository repository = new InMemoryRepairOrderRepository();
        RepairOrder order = TestFixtures.order();

        assertEquals(order, repository.save(order));
        assertEquals(order, repository.findById(order.getId()).orElseThrow());
    }

    @Test
    void duplicateSaveIsRejectedByContract() {
        InMemoryRepairOrderRepository repository = new InMemoryRepairOrderRepository();
        RepairOrder order = TestFixtures.order();
        repository.save(order);

        assertThrows(EntityAlreadyExistsException.class, () -> repository.save(order));
    }

    @Test
    void updateReplacesExistingReferenceAndReturnsIt() {
        InMemoryRepairOrderRepository repository = new InMemoryRepairOrderRepository();
        RepairOrder original = TestFixtures.order();
        repository.save(original);
        RepairOrder replacement = new RepairOrder(original.getId(), original.getCar(),
                original.getPriority(), LocalDateTime.of(2026, 1, 1, 1, 1));

        assertEquals(replacement, repository.update(replacement));
        assertEquals(replacement, repository.findById(original.getId()).orElseThrow());
        assertNotSame(original, repository.findById(original.getId()).orElseThrow());
    }

    @Test
    void updateMissingOrderIsRejected() {
        InMemoryRepairOrderRepository repository = new InMemoryRepairOrderRepository();

        assertThrows(EntityNotFoundException.class, () -> repository.update(TestFixtures.order()));
    }

    @Test
    void missingIdentifierReturnsEmptyOptional() {
        InMemoryRepairOrderRepository repository = new InMemoryRepairOrderRepository();

        assertTrue(repository.findById(UUID.randomUUID()).isEmpty());
    }

    @Test
    void nullArgumentsAreRejected() {
        InMemoryRepairOrderRepository repository = new InMemoryRepairOrderRepository();

        assertThrows(InvalidArgumentException.class, () -> repository.save(null));
        assertThrows(InvalidArgumentException.class, () -> repository.update(null));
        assertThrows(InvalidArgumentException.class, () -> repository.findById(null));
        assertThrows(InvalidArgumentException.class, () -> repository.findByCarVin(null));
        assertThrows(InvalidArgumentException.class, () -> repository.findByMechanic(null));
    }

    @Test
    void searchesOrdersByTrimmedCarVin() {
        InMemoryRepairOrderRepository repository = new InMemoryRepairOrderRepository();
        RepairOrder order = TestFixtures.order();
        repository.save(order);

        assertEquals(List.of(order), repository.findByCarVin(" " + order.getCar().getVin() + " "));
    }

    @Test
    void carSearchDoesNotReturnOrdersForAnotherCar() {
        InMemoryRepairOrderRepository repository = new InMemoryRepairOrderRepository();
        RepairOrder first = TestFixtures.order();
        RepairOrder second = TestFixtures.order();
        repository.save(first);
        repository.save(second);

        assertEquals(List.of(first), repository.findByCarVin(first.getCar().getVin()));
    }

    @Test
    void searchesOrdersByMechanic() {
        InMemoryRepairOrderRepository repository = new InMemoryRepairOrderRepository();
        RepairOrder order = TestFixtures.order();
        Mechanic mechanic = new Mechanic(UUID.randomUUID(), "General", MechanicSpecialization.GENERAL);
        order.assignMechanic(mechanic);
        repository.save(order);

        assertEquals(List.of(order), repository.findByMechanic(mechanic));
    }

    @Test
    void mechanicSearchDoesNotReturnUnassignedOrders() {
        InMemoryRepairOrderRepository repository = new InMemoryRepairOrderRepository();
        RepairOrder order = TestFixtures.order();
        Mechanic mechanic = new Mechanic(UUID.randomUUID(), "General", MechanicSpecialization.GENERAL);
        repository.save(order);

        assertTrue(repository.findByMechanic(mechanic).isEmpty());
    }

    @Test
    void findAllContainsAllSavedOrders() {
        InMemoryRepairOrderRepository repository = new InMemoryRepairOrderRepository();
        RepairOrder first = TestFixtures.order();
        RepairOrder second = TestFixtures.order();
        repository.save(first);
        repository.save(second);

        assertEquals(2, repository.findAll().size());
        assertTrue(repository.findAll().containsAll(List.of(first, second)));
    }

    @Test
    void repositoriesAreStateIsolated() {
        InMemoryRepairOrderRepository firstRepository = new InMemoryRepairOrderRepository();
        InMemoryRepairOrderRepository secondRepository = new InMemoryRepairOrderRepository();
        RepairOrder order = TestFixtures.order();
        firstRepository.save(order);

        assertTrue(secondRepository.findAll().isEmpty());
        assertTrue(secondRepository.findById(order.getId()).isEmpty());
    }

    @Test
    void repeatedUpdateKeepsLatestReference() {
        InMemoryRepairOrderRepository repository = new InMemoryRepairOrderRepository();
        RepairOrder order = TestFixtures.order();
        repository.save(order);
        RepairOrder replacement = new RepairOrder(order.getId(), order.getCar());

        repository.update(replacement);
        repository.update(order);

        assertEquals(order, repository.findById(order.getId()).orElseThrow());
    }
}
