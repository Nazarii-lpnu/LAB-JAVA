package com.example.carservice.domain;

import com.example.carservice.exception.InvalidStateTransitionException;
import com.example.carservice.exception.MechanicNotCompatibleException;
import com.example.carservice.exception.OrderModificationNotAllowedException;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class RepairOrderTest {
    private Customer customer = new Customer(UUID.randomUUID(), "Customer");
    private Car car = new Car("VIN-1", "Brand", "Model", 2020, customer);

    @Test
    void calculatesBaseCostFromPartsAndLabor() {
        RepairOrder order = new RepairOrder(UUID.randomUUID(), car);
        order.addWork(work(MechanicSpecialization.ENGINE, "10.10", "20.20"));
        order.addWork(work(MechanicSpecialization.BRAKES, "5.00", "10.00"));

        assertEquals(new BigDecimal("45.30"), order.calculateBaseCost());
    }

    @Test
    void enforcesLifecycleAndCompletionInvariants() {
        RepairOrder order = new RepairOrder(UUID.randomUUID(), car);
        ServiceWork work = work(MechanicSpecialization.ENGINE, "10.00", "20.00");
        Mechanic mechanic = new Mechanic(UUID.randomUUID(), "Mechanic", MechanicSpecialization.ENGINE);
        order.addWork(work);

        order.diagnose();
        order.approve();
        order.assignMechanic(mechanic);
        order.start();
        assertThrows(InvalidStateTransitionException.class, order::complete);
        order.completeWork(work.getId());
        order.complete();

        assertEquals(OrderStatus.COMPLETED, order.getStatus());
        assertThrows(OrderModificationNotAllowedException.class, () -> order.addWork(work(
                MechanicSpecialization.ENGINE, "1.00", "1.00")));
    }

    @Test
    void rejectsIncompatibleMechanic() {
        RepairOrder order = new RepairOrder(UUID.randomUUID(), car);
        order.addWork(work(MechanicSpecialization.ENGINE, "1.00", "1.00"));

        assertThrows(MechanicNotCompatibleException.class,
                () -> order.assignMechanic(new Mechanic(UUID.randomUUID(), "Mechanic", MechanicSpecialization.BRAKES)));
    }

    private ServiceWork work(MechanicSpecialization specialization, String parts, String labor) {
        return new ServiceWork(UUID.randomUUID(), "Work", specialization,
                new BigDecimal(parts), new BigDecimal(labor), Duration.ofHours(1));
    }
}
