package com.example.carservice.service;

import com.example.carservice.TestFixtures;
import com.example.carservice.domain.Car;
import com.example.carservice.domain.Customer;
import com.example.carservice.domain.Mechanic;
import com.example.carservice.domain.MechanicSpecialization;
import com.example.carservice.domain.RepairOrder;
import com.example.carservice.domain.ServiceWork;
import com.example.carservice.exception.EntityNotFoundException;
import com.example.carservice.exception.InvalidStateTransitionException;
import com.example.carservice.exception.MechanicNotCompatibleException;
import com.example.carservice.pricing.PricingPolicy;
import com.example.carservice.repository.RepairOrderRepository;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

class RepairOrderServiceComprehensiveTest {
    @Test
    void createsOrderThroughRepository() {
        RepairOrderRepository repository = mock(RepairOrderRepository.class);
        RepairOrder order = TestFixtures.order();
        when(repository.save(order)).thenReturn(order);
        RepairOrderService service = new RepairOrderService(repository);

        assertEquals(order, service.create(order));
        verify(repository).save(order);
    }

    @Test
    void retrievesExistingOrder() {
        RepairOrderRepository repository = mock(RepairOrderRepository.class);
        RepairOrder order = TestFixtures.order();
        when(repository.findById(order.getId())).thenReturn(Optional.of(order));

        assertEquals(order, new RepairOrderService(repository).getById(order.getId()));
        verify(repository).findById(order.getId());
    }

    @Test
    void translatesMissingOrderIntoDomainException() {
        RepairOrderRepository repository = mock(RepairOrderRepository.class);
        UUID id = UUID.randomUUID();
        when(repository.findById(id)).thenReturn(Optional.empty());

        assertThrows(EntityNotFoundException.class, () -> new RepairOrderService(repository).getById(id));
    }

    @Test
    void addsWorkAndUpdatesRepository() {
        RepairOrderRepository repository = mock(RepairOrderRepository.class);
        RepairOrder order = TestFixtures.order();
        when(repository.findById(order.getId())).thenReturn(Optional.of(order));
        RepairOrderService service = new RepairOrderService(repository);
        ServiceWork work = TestFixtures.work();

        service.addWork(order.getId(), work);

        assertEquals(List.of(work), order.getWorks());
        verify(repository).update(order);
    }

    @Test
    void removesWorkAndUpdatesRepository() {
        RepairOrderRepository repository = mock(RepairOrderRepository.class);
        RepairOrder order = TestFixtures.order();
        ServiceWork work = TestFixtures.work();
        order.addWork(work);
        when(repository.findById(order.getId())).thenReturn(Optional.of(order));

        new RepairOrderService(repository).removeWork(order.getId(), work.getId());

        assertEquals(List.of(), order.getWorks());
        verify(repository).update(order);
    }

    @Test
    void invalidDomainOperationDoesNotUpdateRepository() {
        RepairOrderRepository repository = mock(RepairOrderRepository.class);
        RepairOrder order = TestFixtures.order();
        when(repository.findById(order.getId())).thenReturn(Optional.of(order));

        assertThrows(InvalidStateTransitionException.class,
                () -> new RepairOrderService(repository).approve(order.getId()));

        verify(repository, never()).update(any());
    }

    @Test
    void calculatesBasePriceFromRetrievedOrder() {
        RepairOrderRepository repository = mock(RepairOrderRepository.class);
        RepairOrder order = TestFixtures.order();
        order.addWork(TestFixtures.work(MechanicSpecialization.ENGINE, "12.00", "8.00", 1));
        when(repository.findById(order.getId())).thenReturn(Optional.of(order));

        assertEquals(new BigDecimal("20.00"),
                new RepairOrderService(repository).calculateBasePrice(order.getId()));
    }

    @Test
    void delegatesCommercialPriceToInjectedPolicyAndPersistsOrder() {
        RepairOrderRepository repository = mock(RepairOrderRepository.class);
        PricingPolicy policy = mock(PricingPolicy.class);
        RepairOrder order = TestFixtures.order();
        when(repository.findById(order.getId())).thenReturn(Optional.of(order));
        when(policy.calculatePrice(order)).thenReturn(new BigDecimal("19.99"));

        assertEquals(new BigDecimal("19.99"),
                new RepairOrderService(repository, policy).calculateCommercialPrice(order.getId()));
        verify(policy).calculatePrice(order);
        verify(repository).update(order);
    }

    @Test
    void doesNotPersistWhenPricingPolicyFails() {
        RepairOrderRepository repository = mock(RepairOrderRepository.class);
        PricingPolicy policy = mock(PricingPolicy.class);
        RepairOrder order = TestFixtures.order();
        when(repository.findById(order.getId())).thenReturn(Optional.of(order));
        when(policy.calculatePrice(order)).thenThrow(new IllegalStateException("pricing failed"));

        assertThrows(IllegalStateException.class,
                () -> new RepairOrderService(repository, policy).calculateCommercialPrice(order.getId()));
        verify(repository, never()).update(any());
    }

    @Test
    void diagnosesAndApprovesOrderThroughService() {
        RepairOrderRepository repository = mock(RepairOrderRepository.class);
        RepairOrder order = TestFixtures.order();
        order.addWork(TestFixtures.work());
        when(repository.findById(order.getId())).thenReturn(Optional.of(order));

        RepairOrderService service = new RepairOrderService(repository);
        service.diagnose(order.getId());
        service.approve(order.getId());

        assertEquals(com.example.carservice.domain.OrderStatus.APPROVED, order.getStatus());
        verify(repository, org.mockito.Mockito.times(2)).update(order);
    }

    @Test
    void assignsCompatibleMechanicAndPersists() {
        RepairOrderRepository repository = mock(RepairOrderRepository.class);
        RepairOrder order = TestFixtures.order();
        order.addWork(TestFixtures.work(MechanicSpecialization.ENGINE, "1.00", "1.00", 1));
        Mechanic mechanic = new Mechanic(UUID.randomUUID(), "Engine", MechanicSpecialization.ENGINE);
        when(repository.findById(order.getId())).thenReturn(Optional.of(order));
        when(repository.findByMechanic(mechanic)).thenReturn(List.of());

        new RepairOrderService(repository).assignMechanic(order.getId(), mechanic);

        assertEquals(mechanic, order.getMechanic());
        verify(repository).update(order);
    }

    @Test
    void rejectsIncompatibleMechanicWithoutPersisting() {
        RepairOrderRepository repository = mock(RepairOrderRepository.class);
        RepairOrder order = TestFixtures.order();
        order.addWork(TestFixtures.work(MechanicSpecialization.ENGINE, "1.00", "1.00", 1));
        Mechanic mechanic = new Mechanic(UUID.randomUUID(), "Brakes", MechanicSpecialization.BRAKES);
        when(repository.findById(order.getId())).thenReturn(Optional.of(order));
        when(repository.findByMechanic(mechanic)).thenReturn(List.of());

        assertThrows(MechanicNotCompatibleException.class,
                () -> new RepairOrderService(repository).assignMechanic(order.getId(), mechanic));
        verify(repository, never()).update(any());
    }

    @Test
    void plansOrderAndPersistsSlot() {
        RepairOrderRepository repository = mock(RepairOrderRepository.class);
        RepairOrder order = TestFixtures.order();
        when(repository.findById(order.getId())).thenReturn(Optional.of(order));

        new RepairOrderService(repository).plan(order.getId(),
                LocalDateTime.of(2026, 1, 1, 9, 0), Duration.ofHours(2));

        assertEquals(LocalDateTime.of(2026, 1, 1, 11, 0), order.getPlannedSlot().getEnd());
        verify(repository).update(order);
    }

    @Test
    void startsOrderAfterValidPreparation() {
        RepairOrderRepository repository = mock(RepairOrderRepository.class);
        RepairOrder order = TestFixtures.order();
        ServiceWork work = TestFixtures.work();
        Mechanic mechanic = new Mechanic(UUID.randomUUID(), "General", MechanicSpecialization.GENERAL);
        order.addWork(work);
        order.diagnose();
        order.approve();
        order.assignMechanic(mechanic);
        when(repository.findById(order.getId())).thenReturn(Optional.of(order));
        when(repository.findByMechanic(mechanic)).thenReturn(List.of(order));

        new RepairOrderService(repository).start(order.getId());

        assertEquals(com.example.carservice.domain.OrderStatus.IN_PROGRESS, order.getStatus());
        verify(repository).update(order);
    }

    @Test
    void delegatesSearchByCarAndMechanic() {
        RepairOrderRepository repository = mock(RepairOrderRepository.class);
        RepairOrder order = TestFixtures.order();
        Mechanic mechanic = new Mechanic(UUID.randomUUID(), "Mechanic", MechanicSpecialization.GENERAL);
        when(repository.findByCarVin(order.getCar().getVin())).thenReturn(List.of(order));
        when(repository.findByMechanic(mechanic)).thenReturn(List.of(order));
        RepairOrderService service = new RepairOrderService(repository);

        assertEquals(List.of(order), service.findByCarVin(order.getCar().getVin()));
        assertEquals(List.of(order), service.findByMechanic(mechanic));
        verify(repository).findByCarVin(order.getCar().getVin());
        verify(repository).findByMechanic(mechanic);
    }

    @Test
    void completesWorkAndOrderThroughService() {
        RepairOrderRepository repository = mock(RepairOrderRepository.class);
        RepairOrder order = TestFixtures.order();
        ServiceWork work = TestFixtures.work();
        order.addWork(work);
        order.diagnose();
        order.approve();
        order.assignMechanic(new Mechanic(UUID.randomUUID(), "General", MechanicSpecialization.GENERAL));
        order.start();
        when(repository.findById(order.getId())).thenReturn(Optional.of(order));

        RepairOrderService service = new RepairOrderService(repository);
        service.completeWork(order.getId(), work.getId());
        service.complete(order.getId());

        assertEquals(com.example.carservice.domain.OrderStatus.COMPLETED, order.getStatus());
        verify(repository, org.mockito.Mockito.times(2)).update(order);
    }

    @Test
    void cancellationIsPersisted() {
        RepairOrderRepository repository = mock(RepairOrderRepository.class);
        RepairOrder order = TestFixtures.order();
        when(repository.findById(order.getId())).thenReturn(Optional.of(order));

        new RepairOrderService(repository).cancel(order.getId());

        assertEquals(com.example.carservice.domain.OrderStatus.CANCELLED, order.getStatus());
        verify(repository).update(order);
    }

    @Test
    void repositoryUpdateFailureIsPropagated() {
        RepairOrderRepository repository = mock(RepairOrderRepository.class);
        RepairOrder order = TestFixtures.order();
        when(repository.findById(order.getId())).thenReturn(Optional.of(order));
        doThrow(new IllegalStateException("storage failure")).when(repository).update(order);

        assertThrows(IllegalStateException.class,
                () -> new RepairOrderService(repository).diagnose(order.getId()));
    }

    @Test
    void nullPricingPolicyIsRejected() {
        RepairOrderRepository repository = mock(RepairOrderRepository.class);

        assertThrows(com.example.carservice.exception.InvalidArgumentException.class,
                () -> new RepairOrderService(repository, null));
    }
}
