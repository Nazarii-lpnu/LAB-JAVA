package com.example.carservice.repository;

import com.example.carservice.domain.Car;
import com.example.carservice.domain.Customer;
import com.example.carservice.domain.RepairOrder;
import com.example.carservice.exception.EntityAlreadyExistsException;
import com.example.carservice.exception.EntityNotFoundException;
import com.example.carservice.repository.inmemory.InMemoryRepairOrderRepository;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class InMemoryRepairOrderRepositoryTest {
    @Test
    void savesAndRetrievesOrder() {
        InMemoryRepairOrderRepository repository = new InMemoryRepairOrderRepository();
        RepairOrder order = order();

        repository.save(order);

        assertSame(order, repository.findById(order.getId()).orElseThrow());
    }

    @Test
    void repeatedSaveIsRejectedAndUpdateRequiresExistingOrder() {
        InMemoryRepairOrderRepository repository = new InMemoryRepairOrderRepository();
        RepairOrder order = order();

        repository.save(order);
        assertThrows(EntityAlreadyExistsException.class, () -> repository.save(order));
        assertThrows(EntityNotFoundException.class, () -> repository.update(order(UUID.randomUUID())));
    }

    @Test
    void searchesByCarVin() {
        InMemoryRepairOrderRepository repository = new InMemoryRepairOrderRepository();
        RepairOrder order = order();
        repository.save(order);

        assertEquals(List.of(order), repository.findByCarVin(" " + order.getCar().getVin() + " "));
    }

    private RepairOrder order() {
        return order(UUID.randomUUID());
    }

    private RepairOrder order(UUID id) {
        Customer customer = new Customer(UUID.randomUUID(), "Customer");
        return new RepairOrder(id, new Car("VIN-" + id, "Brand", "Model", 2020, customer));
    }
}
