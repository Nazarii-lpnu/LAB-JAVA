package com.example.carservice.domain;

import com.example.carservice.TestFixtures;
import com.example.carservice.exception.EntityNotFoundException;
import com.example.carservice.exception.InvalidArgumentException;
import com.example.carservice.exception.InvalidStateTransitionException;
import com.example.carservice.exception.MechanicNotCompatibleException;
import com.example.carservice.exception.OrderModificationNotAllowedException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class RepairOrderComprehensiveTest {
    @Test
    void validOrderStartsCreatedWithNoWorkAndZeroBaseCost() {
        RepairOrder order = TestFixtures.order();

        assertEquals(OrderStatus.CREATED, order.getStatus());
        assertTrue(order.getWorks().isEmpty());
        assertEquals(new BigDecimal("0.00"), order.calculateBaseCost());
    }

    @ParameterizedTest(name = "invalid constructor argument: {0}")
    @MethodSource("invalidConstructorArguments")
    void rejectsMissingRequiredOrderFields(String description, UUID id, Car car,
                                           OrderPriority priority, LocalDateTime createdAt) {
        assertThrows(InvalidArgumentException.class,
                () -> new RepairOrder(id, car, priority, createdAt));
    }

    private static Stream<Arguments> invalidConstructorArguments() {
        Customer customer = TestFixtures.customer();
        Car car = TestFixtures.car(customer);
        return Stream.of(
                Arguments.of("id", null, car, OrderPriority.NORMAL, LocalDateTime.now()),
                Arguments.of("car", UUID.randomUUID(), null, OrderPriority.NORMAL, LocalDateTime.now()),
                Arguments.of("priority", UUID.randomUUID(), car, null, LocalDateTime.now()),
                Arguments.of("createdAt", UUID.randomUUID(), car, OrderPriority.NORMAL, null)
        );
    }

    @Test
    void addsWorkAndCalculatesPartsAndLaborTogether() {
        RepairOrder order = TestFixtures.order();
        order.addWork(TestFixtures.work(MechanicSpecialization.ENGINE, "12.345", "20.125", 1));
        order.addWork(TestFixtures.work(MechanicSpecialization.BRAKES, "7.655", "9.875", 2));

        assertEquals(new BigDecimal("50.00"), order.calculateBaseCost());
        assertEquals(2, order.getWorks().size());
    }

    @Test
    void rejectsNullAndDuplicateWork() {
        RepairOrder order = TestFixtures.order();
        ServiceWork work = TestFixtures.work();
        order.addWork(work);

        assertThrows(InvalidArgumentException.class, () -> order.addWork(null));
        assertThrows(InvalidArgumentException.class, () -> order.addWork(work));
    }

    @Test
    void removesExistingWorkAndUpdatesBaseCost() {
        RepairOrder order = TestFixtures.order();
        ServiceWork work = TestFixtures.work();
        order.addWork(work);

        order.removeWork(work.getId());

        assertTrue(order.getWorks().isEmpty());
        assertEquals(new BigDecimal("0.00"), order.calculateBaseCost());
    }

    @ParameterizedTest(name = "invalid removal id: {0}")
    @MethodSource("invalidWorkIds")
    void rejectsInvalidWorkRemoval(String description, UUID workId,
                                   Class<? extends RuntimeException> expectedException) {
        assertThrows(expectedException, () -> TestFixtures.order().removeWork(workId));
    }

    private static Stream<Arguments> invalidWorkIds() {
        return Stream.of(
                Arguments.of("null", null, InvalidArgumentException.class),
                Arguments.of("unknown", UUID.randomUUID(), EntityNotFoundException.class)
        );
    }

    @Test
    void assignsCompatibleMechanic() {
        RepairOrder order = TestFixtures.order();
        Mechanic mechanic = new Mechanic(UUID.randomUUID(), "Engine specialist", MechanicSpecialization.ENGINE);
        order.addWork(TestFixtures.work(MechanicSpecialization.ENGINE, "1.00", "2.00", 1));

        order.assignMechanic(mechanic);

        assertEquals(mechanic, order.getMechanic());
    }

    @Test
    void rejectsIncompatibleMechanicAssignment() {
        RepairOrder order = TestFixtures.order();
        order.addWork(TestFixtures.work(MechanicSpecialization.ENGINE, "1.00", "2.00", 1));

        assertThrows(MechanicNotCompatibleException.class,
                () -> order.assignMechanic(new Mechanic(UUID.randomUUID(), "Brake specialist",
                        MechanicSpecialization.BRAKES)));
    }

    @Test
    void followsTheCompleteAllowedLifecycle() {
        RepairOrder order = TestFixtures.order();
        ServiceWork work = TestFixtures.work();
        order.addWork(work);
        order.diagnose();
        order.approve();
        order.assignMechanic(new Mechanic(UUID.randomUUID(), "General", MechanicSpecialization.GENERAL));
        order.start();
        order.completeWork(work.getId());
        order.complete();

        assertEquals(OrderStatus.COMPLETED, order.getStatus());
        assertTrue(work.isCompleted());
    }

    @ParameterizedTest(name = "forbidden transition from {0}")
    @MethodSource("forbiddenTransitionOrders")
    void rejectsForbiddenStateTransitions(String currentState, RepairOrder order) {
        assertThrows(InvalidStateTransitionException.class, order::diagnose);
    }

    private static Stream<Arguments> forbiddenTransitionOrders() {
        RepairOrder diagnosed = TestFixtures.order();
        diagnosed.diagnose();
        RepairOrder approved = TestFixtures.order();
        approved.addWork(TestFixtures.work());
        approved.diagnose();
        approved.approve();
        RepairOrder inProgress = TestFixtures.order();
        ServiceWork work = TestFixtures.work();
        inProgress.addWork(work);
        inProgress.diagnose();
        inProgress.approve();
        inProgress.assignMechanic(new Mechanic(UUID.randomUUID(), "General", MechanicSpecialization.GENERAL));
        inProgress.start();
        RepairOrder completed = TestFixtures.order();
        ServiceWork completedWork = TestFixtures.work();
        completed.addWork(completedWork);
        completed.diagnose();
        completed.approve();
        completed.assignMechanic(new Mechanic(UUID.randomUUID(), "General", MechanicSpecialization.GENERAL));
        completed.start();
        completed.completeWork(completedWork.getId());
        completed.complete();
        return Stream.of(
                Arguments.of("DIAGNOSED", diagnosed),
                Arguments.of("APPROVED", approved),
                Arguments.of("IN_PROGRESS", inProgress),
                Arguments.of("COMPLETED", completed),
                Arguments.of("CANCELLED", cancelledOrder())
        );
    }

    private static RepairOrder cancelledOrder() {
        RepairOrder order = TestFixtures.order();
        order.cancel();
        return order;
    }

    @Test
    void cannotApproveWithoutWork() {
        RepairOrder order = TestFixtures.order();
        order.diagnose();

        assertThrows(InvalidStateTransitionException.class, order::approve);
    }

    @Test
    void cannotStartWithoutMechanic() {
        RepairOrder order = TestFixtures.order();
        order.addWork(TestFixtures.work());
        order.diagnose();
        order.approve();

        assertThrows(InvalidStateTransitionException.class, order::start);
    }

    @Test
    void cannotCompleteBeforeAllWorkIsCompleted() {
        RepairOrder order = TestFixtures.order();
        ServiceWork work = TestFixtures.work();
        order.addWork(work);
        order.diagnose();
        order.approve();
        order.assignMechanic(new Mechanic(UUID.randomUUID(), "General", MechanicSpecialization.GENERAL));
        order.start();

        assertThrows(InvalidStateTransitionException.class, order::complete);
    }

    @Test
    void rejectsCompletingUnknownWork() {
        RepairOrder order = TestFixtures.order();
        order.addWork(TestFixtures.work());
        order.diagnose();
        order.approve();
        order.assignMechanic(new Mechanic(UUID.randomUUID(), "General", MechanicSpecialization.GENERAL));
        order.start();

        assertThrows(EntityNotFoundException.class, () -> order.completeWork(UUID.randomUUID()));
    }

    @Test
    void rejectsMutationAfterCompletion() {
        RepairOrder order = completedOrder();

        assertThrows(OrderModificationNotAllowedException.class, () -> order.addWork(TestFixtures.work()));
        assertThrows(OrderModificationNotAllowedException.class, () -> order.removeWork(UUID.randomUUID()));
        assertThrows(OrderModificationNotAllowedException.class,
                () -> order.assignMechanic(new Mechanic(UUID.randomUUID(), "General", MechanicSpecialization.GENERAL)));
    }

    private static RepairOrder completedOrder() {
        RepairOrder order = TestFixtures.order();
        ServiceWork work = TestFixtures.work();
        order.addWork(work);
        order.diagnose();
        order.approve();
        order.assignMechanic(new Mechanic(UUID.randomUUID(), "General", MechanicSpecialization.GENERAL));
        order.start();
        order.completeWork(work.getId());
        order.complete();
        return order;
    }

    @ParameterizedTest(name = "work amount {0} + {1} = {2}")
    @MethodSource("baseCostCases")
    void calculatesBaseCostWithMoneyRounding(String parts, String labor, String expected) {
        RepairOrder order = TestFixtures.order();
        order.addWork(TestFixtures.work(MechanicSpecialization.ENGINE, parts, labor, 1));

        assertEquals(new BigDecimal(expected), order.calculateBaseCost());
    }

    private static Stream<Arguments> baseCostCases() {
        return Stream.of(
                Arguments.of("0.00", "0.00", "0.00"),
                Arguments.of("1.005", "2.005", "3.01"),
                Arguments.of("99.99", "0.01", "100.00")
        );
    }
}
