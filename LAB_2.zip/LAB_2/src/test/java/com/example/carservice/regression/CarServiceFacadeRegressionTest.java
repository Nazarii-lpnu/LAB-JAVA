package com.example.carservice.regression;

import com.example.carservice.domain.Car;
import com.example.carservice.domain.Customer;
import com.example.carservice.domain.Mechanic;
import com.example.carservice.domain.MechanicSpecialization;
import com.example.carservice.domain.OrderStatus;
import com.example.carservice.domain.RepairOrder;
import com.example.carservice.domain.ServiceWork;
import com.example.carservice.repository.inmemory.InMemoryRepairOrderRepository;
import com.example.carservice.service.CarService;
import com.example.carservice.service.RepairOrderService;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;

class CarServiceFacadeRegressionTest {
    @Test
    void preservesLaboratory1OrderFacadeOperations() {
        CarService service = new CarService(new RepairOrderService(new InMemoryRepairOrderRepository()));
        Customer customer = service.registerCustomer("Customer");
        Car car = service.registerCar("VIN-FACADE", "Brand", "Model", 2020, customer.getId());
        Mechanic mechanic = service.registerMechanic("General", MechanicSpecialization.GENERAL);
        RepairOrder order = service.createOrder(car.getVin());
        ServiceWork work = new ServiceWork(UUID.randomUUID(), "Work",
                MechanicSpecialization.ENGINE, new BigDecimal("1.00"),
                new BigDecimal("2.00"), Duration.ofHours(1));

        service.addWorkToOrder(order.getId(), work);
        service.diagnoseOrder(order.getId());
        service.approveOrder(order.getId());
        service.assignMechanic(order.getId(), mechanic.getId());
        service.startOrder(order.getId());
        service.completeWork(order.getId(), work.getId());
        service.completeOrder(order.getId());

        assertEquals(order, service.findOrderById(order.getId()));
        assertEquals(OrderStatus.COMPLETED, order.getStatus());
    }

    @Test
    void preservesGiftLookupOnRepairOrder() {
        RepairOrder order = new RepairOrder(UUID.randomUUID(),
                new Car("VIN-GIFT", "Brand", "Model", 2020, new Customer(UUID.randomUUID(), "Customer")));
        order.addWork(new ServiceWork(UUID.randomUUID(), "Work",
                MechanicSpecialization.ENGINE, new BigDecimal("60.00"),
                new BigDecimal("50.00"), Duration.ofHours(1)));

        assertEquals(com.example.carservice.domain.GiftType.AIR_FRESHENER,
                order.getGift().orElseThrow().getType());
    }
}
