# Laboratory 2 Defense Document

## 1. Architecture overview

The application is organized into domain, service, repository, pricing,
exception, and application packages.

```text
CarServiceDemo
      |
RepairOrderService ---- PricingPolicy ---- CommercialPricingPolicy
      |                                      |
RepairOrderRepository                  PricingRuleEngine
      |                                      |
InMemoryRepairOrderRepository       PricingRule implementations
      |
RepairOrder aggregate
```

`RepairOrder` contains business state and invariants. `RepairOrderService`
coordinates use cases and persistence. `RepairOrderRepository` abstracts
storage. `InMemoryRepairOrderRepository` provides the current storage
implementation. Pricing is injected and separated from the console.

## 2. Main classes

### `RepairOrder`

The aggregate root for a repair order. It manages works, mechanic assignment,
planned time slots, status transitions, completion rules, cancellation, base
cost, and gifts.

### `RepairOrderService`

The application service. It retrieves orders, calls domain operations,
validates mechanic scheduling against repository searches, and updates the
repository after successful operations. It receives repository and pricing
dependencies through constructors.

### `CarService`

A Laboratory 1-compatible facade for customer, car, mechanic, VIN, and order
operations. It delegates order behavior to `RepairOrderService`.

### `RepairOrderRepository`

The persistence abstraction. It supports save, lookup, update, searches by car
VIN and mechanic, and listing all orders.

### `InMemoryRepairOrderRepository`

Stores orders in a private `HashMap`. Duplicate saves fail; updates require an
existing identifier; searches are deterministic by creation time.

### `PricingRuleEngine`

A reusable pricing pipeline that knows nothing about `RepairOrder`,
repositories, or console code. It operates on `PricingInput`,
`PricingContext`, `PricingRule`, and `PricingResult`.

### `CommercialPricingPolicy`

Adapts an order to commercial pricing. It applies the urgent labor multiplier
and delegates configurable rule processing to `PricingRuleEngine`.

### `CarServiceDemo`

Demonstrates saving/retrieving an order, base and commercial pricing, a valid
completion flow, expected failure handling, and continued execution.

## 3. Likely instructor questions and answers

### 1. Why is `RepairOrder` the domain aggregate root?

It owns the works and controls operations that must remain consistent, such as
approval, mechanic compatibility, completion, and terminal-state protection.

### 2. Why is there a separate `RepairOrderService`?

The service coordinates repositories and cross-order scheduling checks. It keeps
application orchestration out of the domain object.

### 3. Why does the service depend on `RepairOrderRepository`?

Dependency inversion allows the service to work with the in-memory repository
or another implementation without changing service logic.

### 4. What happens when an order ID does not exist?

The repository returns `Optional.empty()`. `RepairOrderService.getById` converts
that into `EntityNotFoundException`.

### 5. What does `save` do for a duplicate ID?

`InMemoryRepairOrderRepository.save` throws `EntityAlreadyExistsException`.
Updates must use `update`, and `update` requires an existing ID.

### 6. What is the difference between base and commercial price?

Base price is parts plus labor. Commercial price starts from those components,
applies a 1.20 multiplier to labor for urgent orders, and then runs the
configured pricing rules.

### 7. Why is `BigDecimal` used?

Money must not use binary floating-point arithmetic. `BigDecimal` preserves
decimal values and supports explicit scale and rounding.

### 8. What rounding is used?

Final monetary results use scale 2 and `RoundingMode.HALF_UP`.

### 9. How are pricing rules ordered?

The engine sorts rules by ascending priority and then by rule ID. Discounts
have priority 100; minimum-price rules have priority 1000.

### 10. Why does ordering matter?

For 100.00, a 20% discount followed by a 90.00 minimum produces 90.00.
Applying the minimum first and then discounting would produce 72.00.

### 11. How is duplicate discount application prevented?

Rule IDs must be unique when the engine is constructed. Duplicate IDs are
rejected before calculation.

### 12. Can a pricing rule mutate the input?

No. `PricingInput`, `PricingContext`, and `PricingResult` are immutable.
Rules return a new context through `withPrice`.

### 13. How would you add a surcharge rule?

Implement `PricingRule`, provide a unique ID and priority, calculate the new
amount, and return `context.withPrice(id(), newAmount)`. The engine algorithm
does not change.

### 14. How is mechanic compatibility enforced?

`Mechanic.canPerform` checks specialization, with `GENERAL` matching every
work type. `RepairOrder.assignMechanic` requires compatibility with all works.

### 15. How are schedule conflicts detected?

`RepairOrderService` searches active orders for the mechanic. Missing planned
slots cause `MechanicAlreadyAssignedException`; overlapping slots cause
`ScheduleConflictException`. Completed and cancelled orders are ignored.

### 16. What state transitions are allowed?

The normal flow is `CREATED -> DIAGNOSED -> APPROVED -> IN_PROGRESS ->
COMPLETED`. Cancellation is allowed from `CREATED`, `DIAGNOSED`, and
`APPROVED`. Invalid transitions raise `InvalidStateTransitionException`.

### 17. What is Given–When–Then?

It separates test setup, action, and expected result:

```java
// Given
RepairOrder order = TestFixtures.order();
order.addWork(TestFixtures.work());
order.diagnose();

// When
order.approve();

// Then
assertEquals(OrderStatus.APPROVED, order.getStatus());
```

### 18. How is Mockito used?

The application-service tests mock `RepairOrderRepository` and `PricingPolicy`.
They stub retrieval or pricing, invoke the service, and verify required
interactions:

```java
when(repository.findById(order.getId())).thenReturn(Optional.of(order));
when(policy.calculatePrice(order)).thenReturn(new BigDecimal("19.99"));

BigDecimal result = service.calculateCommercialPrice(order.getId());

verify(policy).calculatePrice(order);
verify(repository).update(order);
```

### 19. How many tests exist?

There are 101 unique test methods, including 9 parameterized methods. The
latest direct JUnit Platform execution ran 123 cases: 123 passed, 0 failed,
and 0 skipped.

### 20. How should tests be run?

With Maven installed:

```text
mvn clean test
```

The current audit machine did not have Maven available, so the direct JUnit
run with cached dependencies was used for execution verification. A successful
Maven run also creates the JaCoCo report under `target/site/jacoco`.

## 4. Test organization

Tests are grouped by responsibility:

- `domain`: order construction, validation, state transitions, work, and cost.
- `service`: orchestration, repository interactions, pricing delegation, and
  invalid-operation persistence guarantees.
- `repository`: save, update, retrieval, searches, isolation, and boundaries.
- `pricing`: base/commercial pricing, discounts, minimum prices, rounding,
  rule ordering, immutability, and deterministic repeated calls.
- `regression`: Laboratory 1 behavior including scheduling, gifts, searches,
  facade operations, mechanic assignment, and lifecycle behavior.

Parameterized tests cover constructor validation, invalid IDs, base-cost
rounding, discount boundaries, minimum-price boundaries, time-slot validation,
gift thresholds, and forbidden transitions.
